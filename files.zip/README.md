# 🤖 AI Chatbot

A general-purpose AI chatbot built with Python and OpenAI's GPT-3.5-turbo.
Runs both in the **terminal** and as a **web app** via Streamlit.

---

## ✨ Features

- 💬 Multi-turn conversation with memory
- 🎭 4 switchable personalities (Helpful, Tutor, Sarcastic, ELI5)
- 💾 Save chat history to a text file
- 🧹 Clear conversation and start fresh
- 🌐 Clean web UI built with Streamlit
- 📊 Message counter in sidebar

---

## 🚀 Setup

### 1. Clone / download this project

```bash
git clone https://github.com/YOUR_USERNAME/chatbot.git
cd chatbot
```

### 2. Create a virtual environment

```bash
python -m venv venv

# Windows:
venv\Scripts\activate

# Mac/Linux:
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Add your OpenAI API key

Copy `.env.example` to `.env` and paste your key:

```bash
cp .env.example .env
```

Edit `.env`:
```
OPENAI_API_KEY=sk-your-actual-key-here
```

Get your key at: https://platform.openai.com/api-keys

---

## ▶️ Run the chatbot

### Terminal version:
```bash
python chatbot.py
```

### Web app version:
```bash
streamlit run streamlit_app.py
```

Then open http://localhost:8501 in your browser.

---

## 📁 Project Structure

```
chatbot/
├── chatbot.py          # Core chatbot logic + terminal interface
├── streamlit_app.py    # Web UI
├── requirements.txt    # Dependencies
├── .env.example        # API key template
├── .env                # Your actual key (not pushed to GitHub)
├── .gitignore
└── README.md
```

---

## 🛠️ Tech Stack

- **Python 3.9+**
- **OpenAI API** (GPT-3.5-turbo)
- **Streamlit** (web UI)
- **python-dotenv** (environment variables)

---

## ☁️ Deploy for Free

1. Push to GitHub
2. Go to https://streamlit.io/cloud
3. Connect your repo and deploy — done!

> Make sure to add `OPENAI_API_KEY` in Streamlit Cloud's **Secrets** settings.
